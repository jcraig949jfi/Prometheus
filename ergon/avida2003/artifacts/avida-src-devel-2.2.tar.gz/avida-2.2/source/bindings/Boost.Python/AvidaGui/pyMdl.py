
class pyMdl:
  pass
